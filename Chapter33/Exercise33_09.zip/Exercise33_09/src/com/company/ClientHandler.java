package com.company;

import java.io.*;
import java.net.Socket;

class ClientHandler extends Thread {
    private DataInputStream dis;
    private DataOutputStream dos;
    private Socket socket;

    public ClientHandler(Socket s) {
        this.socket = s;
    }

    @Override
    public void run() {
        try {
            dos = (DataOutputStream) socket.getOutputStream();
            dis = (DataInputStream) socket.getInputStream();
            String line = dis.toString();
            dos.writeUTF(line);
            dos.flush();
            dos.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}