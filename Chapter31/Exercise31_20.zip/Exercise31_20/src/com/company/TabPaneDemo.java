package com.company;
import javafx.application.Application;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class TabPaneDemo extends Application {
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        TabPane tabPane = new TabPane();
        tabPane.setSide(Side.TOP);
        Tab tab1 = new Tab("Line");
        StackPane pane1 = new StackPane();
        pane1.getChildren().add(new Line(10, 10, 80, 80));
        tab1.setContent(pane1);
        Tab tab2 = new Tab("Rectangle");
        tab2.setContent(new Rectangle(10, 10, 200, 200));
        Tab tab3 = new Tab("Circle");
        tab3.setContent(new Circle(50, 50, 20));
        Tab tab4 = new Tab("Ellipse");
        tab4.setContent(new Ellipse(10, 10, 100, 80));
        tabPane.getTabs().addAll(tab1, tab2, tab3, tab4);

        ToggleGroup group = new ToggleGroup();
        GridPane gridPane = new GridPane();

        RadioButton rbTop = new RadioButton("Top");
        rbTop.setToggleGroup(group);
        gridPane.add(rbTop,0,0);
        RadioButton rbLeft = new RadioButton("Left");
        rbLeft.setToggleGroup(group);
        gridPane.add(rbLeft,1,0);
        RadioButton rbBottom = new RadioButton("Bottom");
        rbBottom.setToggleGroup(group);
        gridPane.add(rbBottom,2,0);
        RadioButton rbRight = new RadioButton("Right");
        rbRight.setToggleGroup(group);
        rbTop.setSelected(true);
        gridPane.add(rbRight,3,0);

        group.selectedToggleProperty().addListener((ov, old_toggle, new_toggle) -> {
                if (rbTop.isSelected())
                    tabPane.setSide(Side.TOP);
                if (rbLeft.isSelected())
                    tabPane.setSide(Side.LEFT);
                if (rbBottom.isSelected())
                    tabPane.setSide(Side.BOTTOM);
                if (rbRight.isSelected())
                    tabPane.setSide(Side.RIGHT);
        });


        GridPane radioPane = new GridPane();
        radioPane.add(tabPane,0,0);
        radioPane.add(gridPane,0,1);

        Scene scene = new Scene(radioPane, 300, 250);
        primaryStage.setTitle("DisplayFigure"); // Set the window title
        primaryStage.setScene(scene); // Place the scene in the window
        primaryStage.show(); // Display the window
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     * line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}