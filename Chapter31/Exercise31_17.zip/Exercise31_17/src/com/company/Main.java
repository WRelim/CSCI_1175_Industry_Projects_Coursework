package com.company;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.text.NumberFormatter;
import java.text.NumberFormat;


public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        NumberFormatter formatter = new NumberFormatter(NumberFormat.getInstance());
        formatter.setValueClass(Double.class);
        formatter.setMinimum(0.0);
        formatter.setMaximum(Double.MAX_VALUE);
        formatter.setAllowsInvalid(false);
        formatter.setCommitsOnValidEdit(true);


        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(5);

        MenuBar menuBar = new MenuBar();
        Menu menu = new Menu("Operation");
        MenuItem m1 = new MenuItem("Calculate");
        MenuItem m2 = new MenuItem("Exit");
        menu.getItems().addAll(m1,m2);
        menuBar.getMenus().add(menu);

        m2.setOnAction(e -> System.exit(0));

        TextField tfInvestmentAmount = new TextField();
        tfInvestmentAmount.setAlignment(Pos.CENTER_RIGHT);

        TextField tfYears = new TextField();
        tfYears.setAlignment(Pos.CENTER_RIGHT);

        TextField tfAnnualInterestRate = new TextField();
        tfAnnualInterestRate.setAlignment(Pos.CENTER_RIGHT);

        TextField tfFutureValue = new TextField();
        tfFutureValue.setAlignment(Pos.CENTER_RIGHT);
        tfFutureValue.setEditable(false);

        pane.add(new Label("Investment Amount:"),0,1);
        pane.add(tfInvestmentAmount, 1,1);

        pane.add(new Label("Number of Years:"),0,2);
        pane.add(tfYears, 1,2);

        pane.add(new Label("Annual Interest Rate:"),0,3);
        pane.add(tfAnnualInterestRate, 1,3);

        pane.add(new Label("Future Value:"),0,4);
        pane.add(tfFutureValue, 1,4);

        Button button = new Button("Calculate");
        button.setOnAction(event -> {
            Calculator calculator = new Calculator(
                    Double.parseDouble(tfInvestmentAmount.getText()),
                    Double.parseDouble(tfAnnualInterestRate.getText()),
                    Integer.parseInt(tfYears.getText())
                    );
            System.out.println(calculator.futureValue());
            String result = String.valueOf(String.format("%.2f", calculator.futureValue()));
            tfFutureValue.setText(result);
        });
        pane.add(button,1,5);
        VBox root = new VBox();
        root.getChildren().addAll(menuBar,pane);

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setTitle("Investment Calculator"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }

    public static void main(String[] args) {
        launch(args);
    }

}
