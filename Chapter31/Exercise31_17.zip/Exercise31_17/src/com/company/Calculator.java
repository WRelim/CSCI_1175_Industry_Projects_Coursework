package com.company;

public class Calculator {
    private double investmentAmount;
    private double monthlyInterestRate;
    private int years;

    Calculator() {

    }

    Calculator(double investmentAmount, double annualInterestRate, int years) {
        this.investmentAmount = investmentAmount;
        this.monthlyInterestRate = annualInterestRate / 1200;
        this.years = years;
    }
    public double futureValue() {
        int months = years * 12;
        return investmentAmount * Math.pow(1 + monthlyInterestRate, months);
    }
    public void setInvestmentAmount(double investmentAmount) {
        this.investmentAmount = investmentAmount;
    }
    public double getInvestmentAmount() {
        return investmentAmount;
    }
    public void setMonthlyInterestRate(double annualInterestRate) {
        this.monthlyInterestRate = annualInterestRate * 12;
    }
    public double getMonthlyInterestRate() {
        return monthlyInterestRate;
    }
    public void setNumberOfYears(int years) {
        this.years = years;
    }
    public int NumberOfYears() {
        return years;
    }
}
